export function httpGet(url) {
  throw new Error(url);
}

export function httpPost(url) {
  throw new Error(url);
}
