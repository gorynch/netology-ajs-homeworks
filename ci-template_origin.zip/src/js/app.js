// TODO: write your code here
import sum from './basic';

console.log('worked');

console.log(sum([1, 2]));
